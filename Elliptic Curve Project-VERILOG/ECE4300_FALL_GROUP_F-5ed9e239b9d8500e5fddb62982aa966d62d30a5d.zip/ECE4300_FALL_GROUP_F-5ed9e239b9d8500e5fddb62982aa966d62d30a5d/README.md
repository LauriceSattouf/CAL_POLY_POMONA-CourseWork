# ECE4300_FALL_GROUP_F

This project demonstrates hardware based implementation of Elliptic Curve Cryptography (ECC) using field programmable gate arrays (FPGA's). To improve hardware performance, curve points exist in the binary field.

<br>
<br>

Binary Fields
------------------

Binary Field Order 4 - Elements are the 2^4 binary polynomials of at most degree 3
{ 0,      1,      z,    z + 1,
  z^2     z^2+1.... z^3+z^2+z+1 }
  

Register Representation of Order 4 Binary Field
Examples
1) z^2 + z + 1 == 0111
2) z^3 + 1 == 1001

<br>

<h3> Reduction Polynomial </h3>

When we multiply two polynomials we will get a result with a degree larger than our original order. In this case, larger than order 4 (x^3+z^2+z^1+z^0). To perform multiplication on these polynomials, we need to reduce the result to something that can fit into our registers [3:0]. To accomplish this, the result is modulo an irreducible function of an order higher. In this case order 5.

In degree 4 there are three irreducible functions listed below. Any can be used but it must remain consistent.
1) f1(z) = z^4 +z + 1
2) f2(z) = z^4 +z^3 + 1
3) f3(z) = z4+z3 +z2 +z + 1

<br>

<h3>Binary Field Arithmetic </h3>

| Operation       | Process         | Comments |
| --------------- | --------------- | --------------- |
| Addition | ((z^3+z^2+1) + (z^2+z+1)) % 2 <br> = (z^3 + 2z^2 + z + 2) % 2 <br> = z^3 + z|  |
| Subtraction | - |  Since we are taking modulus 2 it is actually identical to addition |
| Multiplication | (z3 + z2 + 1)·(z2 + z +1) = z5 + z +1 <br> z5 + z +1 mod (z4 + z +1) = z2 +1 | Modulo the reduction polynomial reduces result to the needed order |
| Inversion | (z3 + z2 +1)·z2 mod (z4 + z +1) = 1 | therefore z2 is the inverse of (z3 + z2 + 1). The method for finding this is sort of brute force so a simple equation is not shown. |

<br>
<br>

Elliptic Curves
--------------------

<h3>Elliptic Curve Format </h3>
y^2 + xy = x^3 + ax^2 + b </br>
</br>
example </br>
a: z^3</br>
b: z^3 + 1</br>
y^2 + xy = x^3 + z^3x^2 + (z^3 + 1)</br>

<br>

<h3>Elliptic Curve Point Operations </h3>

1) Negatives
2) Addition
3) Doubling

<br>

<h3>Elliptic Curve Points over a Binary Field </h3>
<h5>(order 4 using reduction polynomial f(z) = z4 + z + 1 )</h5>

|  |  |  | |
| --------------- | --------------- | --------------- |--------------- |
| ∞ | (0011,1100) | (1000,0001) |(1100,0000)|
| (0000,1011) | (0011,1111) | (1000,1001) | (1100,1100) |
| (0001,0000) | (0101,0000) | (1001,0110) | (1111,0100) |
| (0001,0001) | (0101,0101) | (1001,1111) | (1111,1011) |
| (0010,1101) | (0111,1011) | (1011,0010)
| (0010,1111) | (0111,1100) | (1011,1001)

Note: The reduction polynomial chosen will change the order that these points appear. 

Higher orders will result in more points and greater security.

<br>

<h3>Point Scalar Multiplication </h3>

Multiplication is the heart of elliptic curve cryptography. When given a scalar, k, the ecryption algorithm must calculate a point kP which represents a point in the binary field as described above. <br>
There are multiple methods for determining the scalar multiple of a point but they all involve using the operations such as point doubling and addition.

<br>
<br>

Encryption Process
--------------------

<h3>Public Parameters</h3>
a, b  : Curve Parameters <br>
G     : Generator Point <br>
n:    : Order

<h3>Example Scenario</h3>


| Alice           |       Bob       | 
| --------------- | --------------- |
| Randomly, and secretly, picks k value, u            | Randomly, and secretly, picks k value, v
| Computes A = uG, using point scalar multiplication  | Computes B = vG, using point scalar multiplication
| Receives point B from Bob                           | Receives point A from Alice
| Computes uB = P                                     | Computes vA = P

Both users now have the same point P since point multiplication is commutative. Security comes from the difficulty in determining k used to create P. 



Sources
-----------

Hankerson, Darrel R., et al. Guide to Elliptic Curve Cryptography. Springer, 2010. 
